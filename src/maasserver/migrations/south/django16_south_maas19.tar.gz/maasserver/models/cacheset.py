# Copyright 2015 Canonical Ltd.  This software is licensed under the
# GNU Affero General Public License version 3 (see the file LICENSE).

"""Model for a Bcache cache set."""

from __future__ import (
    absolute_import,
    print_function,
    unicode_literals,
    )

str = None

__metaclass__ = type
__all__ = [
    'CacheSet',
    ]

from maasserver import DefaultMeta
from maasserver.models.cleansave import CleanSave
from maasserver.models.timestampedmodel import TimestampedModel


class CacheSet(CleanSave, TimestampedModel):
    """A Bcache cache set."""

    class Meta(DefaultMeta):
        """Needed for South to recognize this model."""
